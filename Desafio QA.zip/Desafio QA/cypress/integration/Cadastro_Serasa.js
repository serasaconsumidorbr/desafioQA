// Cadastro_Serasa.js created with Cypress
//
// Start writing your Cypress tests below!
// If you're unfamiliar with how Cypress works,
// check out the link below and learn how to write your first test:
// https://on.cypress.io/writing-first-test

describe('Cadastra no Portal do Serasa', function() {
  it('Cadastra no Portal do Serasa', function() {
	cy.visit('https://www.serasa.com.br')
	cy.contains('Consultar CPF grátis').click()
	cy.get('#cpf').type('04688852002')
	cy.contains('Confirmar').click()
	cy.wait(5000)
	cy.get('#name').type('Gabriel Bahlis Paixão')
	cy.get('#birthDate').type('02052013')
	cy.get('#email').type('gabopaixao@gmail.com')
	cy.get('#password').type('gabrielteste')
	cy.get('#terms').click()
	cy.contains('CRIAR CONTA GRÁTIS').click()
	
    expect(true).to.equal(true)
  })
})