//Esquema do Cenário: Identificar CPF não cadastrado para acesso ao Portal Serasa
  
//  Dado que acessei o site "https://www.serasa.com.br/"
//  E não possuo CPF cadastrado no Serasa
//  E acessei o botão "<botao>"
//  Quando preencher o CPF 
//  Então serei direcionado para o endereço "https://www.serasa.com.br/cadastrar?product=portal&redirectUrl=%2Farea-cliente" 
// https://on.cypress.io/writing-first-test


describe('Acesso ao Portal Serasa', function() {
  
  it('Acessa o Portal do Serasa', function() {
	cy.visit('https://www.serasa.com.br')
	cy.contains('Consultar CPF grátis').should('be.visible')
	cy.contains('Consultar CPF grátis').click()
	cy.get('#cpf').type('82964548072')
	cy.contains('Confirmar').click()
	cy.wait(5000)
	cy.get('#password').type('M4rt1n4!')
	cy.contains('Confirmar').click()
    cy.contains('Saúde financeira').click()
	cy.contains('Entenda sua saúde financeira').should('be.visible')
  })
})